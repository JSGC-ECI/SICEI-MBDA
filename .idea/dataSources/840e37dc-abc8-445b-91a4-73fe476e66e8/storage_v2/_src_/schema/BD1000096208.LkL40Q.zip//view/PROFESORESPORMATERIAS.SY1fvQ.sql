create view PROFESORESPORMATERIAS as
SELECT m.nombre AS nombreMateria, m.idMateria, p.nombre AS nombreProfesor
FROM materias m
         JOIN grupos g ON m.idMateria = g.idMateria
         JOIN profesores p ON g.idProfesor = p.idUsuario
/

