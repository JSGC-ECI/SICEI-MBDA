create view MENOSES as
SELECT m.nombre, COUNT(mpe.idEstudiante) AS NumeroEstudiantes
FROM materias m
         LEFT JOIN materiasporestudiante mpe ON m.idMateria = mpe.idMateria
GROUP BY m.idMateria, m.nombre
ORDER BY NumeroEstudiantes
/

