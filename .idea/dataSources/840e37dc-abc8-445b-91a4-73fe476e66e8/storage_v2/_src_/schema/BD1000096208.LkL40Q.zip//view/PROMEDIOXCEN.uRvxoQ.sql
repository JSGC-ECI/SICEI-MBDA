create view PROMEDIOXCEN as
SELECT c.nombre, AVG(n.valor) AS promedio_valor
FROM notas n
         JOIN materias m ON n.idMateria = m.idMateria
         JOIN centrosdeestudios c ON m.idCentroDeEstudios = c.idCentroEstudios
GROUP BY c.nombre
/

