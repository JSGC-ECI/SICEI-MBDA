create view NOTASXMAT as
SELECT n.idNota, n.tipoDeEvaluacion, m.nombre, n.valor
FROM notas n
         JOIN materias m ON n.idMateria = m.idMateria
/

