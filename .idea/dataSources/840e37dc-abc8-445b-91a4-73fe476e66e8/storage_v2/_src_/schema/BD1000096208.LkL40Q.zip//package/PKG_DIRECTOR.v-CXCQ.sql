create PACKAGE PKG_DIRECTOR
IS
    -- Declaración de procedimientos y funciones para la gestión de componentes
    PROCEDURE ();
    PROCEDURE ();
    PROCEDURE ();
    PROCEDURE ();
    PROCEDURE ();
    PROCEDURE ();
    PROCEDURE ();
    PROCEDURE ();

END PKG_COMPONENTES;
/

