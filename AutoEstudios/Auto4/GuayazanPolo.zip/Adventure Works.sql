--Tablas

CREATE TABLE Customer (
    CustomerID NUMBER,
    FirstName VARCHAR2(50),
    MiddleName VARCHAR2(50),
    LastName VARCHAR2(50),
    CompanyName VARCHAR2(100),
    EmailAddress VARCHAR2(100)
);

CREATE TABLE Address (
    AddressID NUMBER,
    AddressLine1 VARCHAR2(255),
    AddressLine2 VARCHAR2(255),
    City VARCHAR2(100),
    StateProvince VARCHAR2(100),
    CountyRegion VARCHAR2(100),
    PostalCode VARCHAR2(20)
);

CREATE TABLE CustomerAddress (
    CustomerID NUMBER,
    AddressID NUMBER,
    AddressType VARCHAR2(50)
);

CREATE TABLE SalesOrderHeader (
    SalesOrderID NUMBER,
    RevisionNumber NUMBER,
    OrderDate DATE,
    CustomerID NUMBER,
    BillToAddressID NUMBER,
    ShipToAddressID NUMBER,
    ShipMethod VARCHAR2(100),
    SubTotal NUMBER(10,2),
    TaxAmt NUMBER(10,2),
    Freight NUMBER(10,2)
);

CREATE TABLE SalesOrderDetail (
    SalesOrderID NUMBER,
    SalesOrderDetailID NUMBER,
    OrderQty NUMBER,
    ProductID NUMBER,
    UnitPrice NUMBER(10,2),
    UnitPriceDiscount NUMBER(10,2)
);

CREATE TABLE ProductModel (
    ProductModelID NUMBER,
    Name VARCHAR2(100,
    catalogDescription VARCHAR2(255)
);

CREATE TABLE ProductCategory (
    ProductCategoryID NUMBER,
    ParentProductCategoryID NUMBER,
    Name VARCHAR2(100)
);

CREATE TABLE Product (
    ProductID NUMBER,
    Name VARCHAR2(100),
    Color VARCHAR2(50),
    ListPrice NUMBER(10,2),
    SizeP VARCHAR2(50),
    Weight NUMBER(10,2),
    ProductModelID NUMBER,
    ProductCategoryID NUMBER
);

CREATE TABLE ProductDescription (
    ProductDescriptionID NUMBER,
    Description VARCHAR2(255),
);

CREATE TABLE ProductModelProductDescription (
    ProductModelID NUMBER,
    ProductDescriptionID NUMBER,
    Culture VARCHAR2(10)
);

-- Atributos, Primarias, Unicas, Foraneas

ALTER TABLE ADDRESS
ADD CONSTRAINT PK_Address PRIMARY KEY (ADDRESSID);

ALTER TABLE CUSTOMER
ADD CONSTRAINT PK_Customer PRIMARY KEY (CUSTOMERID);

ALTER TABLE CUSTOMERADDRESS
ADD CONSTRAINT PK_CustomerAddress PRIMARY KEY (CUSTOMERID, ADDRESSTYPE);

ALTER TABLE SALESORDERHEADER
ADD CONSTRAINT PK_SalesOrderHeader PRIMARY KEY (SALESORDERID);

ALTER TABLE SALESORDERDETAIL
ADD CONSTRAINT PK_SalesOrderDetail PRIMARY KEY (SALESORDERDETAILID);

ALTER TABLE PRODUCT
ADD CONSTRAINT PK_Product PRIMARY KEY (PRODUCTID);

ALTER TABLE PRODUCTMODEL
ADD CONSTRAINT PK_ProductModel PRIMARY KEY (PRODUCTMODELID);

ALTER TABLE PRODUCTCATEGORY
ADD CONSTRAINT PK_ProductCategory PRIMARY KEY (PRODUCTCATEGORYID);

ALTER TABLE PRODUCTMODELPRODUCTDESCRIPTION
ADD CONSTRAINT PK_ProductModelProductDescription PRIMARY KEY (PRODUCTMODELID, PRODUCTDESCRIPTIONID, CULTURE);

ALTER TABLE PRODUCTDESCRIPTION
ADD CONSTRAINT PK_ProductDescription PRIMARY KEY (PRODUCTDESCRIPTIONID);

ALTER TABLE CUSTOMERADDRESS
ADD CONSTRAINT FK_CustomerAddress_Customer FOREIGN KEY (CUSTOMERID) REFERENCES Customer(CUSTOMERID);

ALTER TABLE CUSTOMERADDRESS
ADD CONSTRAINT FK_CustomerAddress_Address FOREIGN KEY (ADDRESSID) REFERENCES Address(ADDRESSID);

ALTER TABLE SALESORDERHEADER
ADD CONSTRAINT FK_SalesOrderHeader_Customer FOREIGN KEY (CUSTOMERID) REFERENCES Customer(CUSTOMERID);

ALTER TABLE SALESORDERHEADER
ADD CONSTRAINT FK_SalesOrderHeader_BillTo FOREIGN KEY (BILLTOADDRESSID) REFERENCES Address(ADDRESSID);

ALTER TABLE SALESORDERHEADER
ADD CONSTRAINT FK_SalesOrderHeader_ShipTo FOREIGN KEY (SHIPTOADDRESSID) REFERENCES Address(ADDRESSID);

ALTER TABLE SALESORDERDETAIL
ADD CONSTRAINT FK_SalesOrderDetail_Order FOREIGN KEY (SALESORDERID) REFERENCES SalesOrderHeader(SALESORDERID);

ALTER TABLE SALESORDERDETAIL
ADD CONSTRAINT FK_SalesOrderDetail_Product FOREIGN KEY (PRODUCTID) REFERENCES Product(PRODUCTID);

ALTER TABLE PRODUCT
ADD CONSTRAINT FK_Product_Model FOREIGN KEY (PRODUCTMODELID) REFERENCES ProductModel(PRODUCTMODELID);

ALTER TABLE PRODUCT
ADD CONSTRAINT FK_Product_Category FOREIGN KEY (PRODUCTCATEGORYID) REFERENCES ProductCategory(PRODUCTCATEGORYID);

ALTER TABLE PRODUCTCATEGORY
ADD CONSTRAINT FK_ProductCategory_Parent FOREIGN KEY (PARENTPRODUCTCATEGORYID) REFERENCES ProductCategory(PRODUCTCATEGORYID);

ALTER TABLE CUSTOMER
ADD CONSTRAINT UK_Customer UNIQUE (EMAILADDRESS);

-- PoblarOk

insert into Customer (CustomerID, FirstName, MiddleName, LastName, CompanyName, EmailAddress) values (1, 'Martita', 'Danella', 'Fernyhough', 'Skivee', 'dfernyhough0@github.io');
insert into Customer (CustomerID, FirstName, MiddleName, LastName, CompanyName, EmailAddress) values (2, 'Blondelle', 'Emily', 'Jaulme', 'Mydeo', 'ejaulme1@ca.gov');
insert into Customer (CustomerID, FirstName, MiddleName, LastName, CompanyName, EmailAddress) values (3, 'Bamby', 'Stavros', 'Readshaw', 'Wikido', 'sreadshaw2@kickstarter.com');
insert into Customer (CustomerID, FirstName, MiddleName, LastName, CompanyName, EmailAddress) values (4, 'Ermanno', null, 'Liebermann', 'Zava', 'kliebermann3@telegraph.co.uk');
insert into Customer (CustomerID, FirstName, MiddleName, LastName, CompanyName, EmailAddress) values (5, 'Belia', 'Kirsten', 'Maffione', 'Babbleopia', 'kmaffione4@flickr.com');
insert into Customer (CustomerID, FirstName, MiddleName, LastName, CompanyName, EmailAddress) values (6, 'Ulrich', 'Donia', 'Vreede', 'Yombu', 'dvreede5@liveinternet.ru');
insert into Customer (CustomerID, FirstName, MiddleName, LastName, CompanyName, EmailAddress) values (7, 'Clea', 'Gard', 'Zottoli', 'Podcat', 'gzottoli6@usnews.com');
insert into Customer (CustomerID, FirstName, MiddleName, LastName, CompanyName, EmailAddress) values (8, 'Margery', 'Ellen', 'Ride', 'Bubbletube', 'eride7@dagondesign.com');
insert into Customer (CustomerID, FirstName, MiddleName, LastName, CompanyName, EmailAddress) values (9, 'Daveen', 'Leicester', 'Tremeer', 'Voolia', 'ltremeer8@cbc.ca');
insert into Customer (CustomerID, FirstName, MiddleName, LastName, CompanyName, EmailAddress) values (10, 'Caroljean', 'Sioux', 'Frankema', 'Skalith', 'sfrankema9@samsung.com');
insert into Customer (CustomerID, FirstName, MiddleName, LastName, CompanyName, EmailAddress) values (11, 'Brear', 'Michelle', 'Andrioli', 'Youopia', 'mandriolia@npr.org');
insert into Customer (CustomerID, FirstName, MiddleName, LastName, CompanyName, EmailAddress) values (12, 'Reinhold', 'Glenna', 'Maccrae', 'Youtags', 'gmaccraeb@cpanel.net');
insert into Customer (CustomerID, FirstName, MiddleName, LastName, CompanyName, EmailAddress) values (13, 'Isadora', 'Lizbeth', 'Kleinplatz', 'Oyonder', 'lkleinplatzc@skype.com');
insert into Customer (CustomerID, FirstName, MiddleName, LastName, CompanyName, EmailAddress) values (14, 'Gill', 'Selie', 'Giller', 'Fadeo', 'sgillerd@hao123.com');
insert into Customer (CustomerID, FirstName, MiddleName, LastName, CompanyName, EmailAddress) values (15, 'Maisey', 'Marijo', 'MacAvaddy', 'Jabberbean', 'mmacavaddye@netvibes.com');
insert into Customer (CustomerID, FirstName, MiddleName, LastName, CompanyName, EmailAddress) values (16, 'Ula', 'Casey', 'Cory', 'Eadel', 'ccoryf@t.co');
insert into Customer (CustomerID, FirstName, MiddleName, LastName, CompanyName, EmailAddress) values (17, 'Giavani', 'Laetitia', 'Petegrew', 'Demizz', 'lpetegrewg@bbb.org');
insert into Customer (CustomerID, FirstName, MiddleName, LastName, CompanyName, EmailAddress) values (18, 'Nadeen', null, 'Mawd', 'Meembee', 'emawdh@cloudflare.com');
insert into Customer (CustomerID, FirstName, MiddleName, LastName, CompanyName, EmailAddress) values (19, 'Trevar', 'Madison', 'Copper', 'Kimia', 'mcopperi@chicagotribune.com');
insert into Customer (CustomerID, FirstName, MiddleName, LastName, CompanyName, EmailAddress) values (20, 'Fonzie', 'Karena', 'Jonin', 'Twitterbridge', 'kjoninj@creativecommons.org');

insert into Address (AddressID, AddressLine1, AddressLine2, City, StateProvince, CountyRegion, PostalCode) values (1, '61 Jay Plaza', 'Suite 35', 'Brooklyn', 'New York', 'United States', '11254');
insert into Address (AddressID, AddressLine1, AddressLine2, City, StateProvince, CountyRegion, PostalCode) values (2, '0 Weeping Birch Road', 'Room 936', 'Ipaba', null, 'Brazil', '35198-000');
insert into Address (AddressID, AddressLine1, AddressLine2, City, StateProvince, CountyRegion, PostalCode) values (3, '514 Dawn Drive', 'Room 1628', 'El Dividive', null, 'Venezuela', null);
insert into Address (AddressID, AddressLine1, AddressLine2, City, StateProvince, CountyRegion, PostalCode) values (4, '80551 Kenwood Park', 'PO Box 84343', 'Bujanovac', null, 'Serbia', null);
insert into Address (AddressID, AddressLine1, AddressLine2, City, StateProvince, CountyRegion, PostalCode) values (5, '001 Delaware Road', 'PO Box 94165', 'Ziębice', null, 'Poland', '57-220');
insert into Address (AddressID, AddressLine1, AddressLine2, City, StateProvince, CountyRegion, PostalCode) values (6, '441 Mockingbird Court', 'Room 1926', 'Revda', null, 'Russia', '623287');
insert into Address (AddressID, AddressLine1, AddressLine2, City, StateProvince, CountyRegion, PostalCode) values (7, '39193 Mayer Terrace', 'PO Box 5139', 'El Crucero', null, 'Nicaragua', null);
insert into Address (AddressID, AddressLine1, AddressLine2, City, StateProvince, CountyRegion, PostalCode) values (8, '5086 Comanche Lane', '10th Floor', 'San Vicente', null, 'Philippines', '6419');
insert into Address (AddressID, AddressLine1, AddressLine2, City, StateProvince, CountyRegion, PostalCode) values (9, '313 Macpherson Terrace', 'Apt 1849', 'Topeka', 'Kansas', 'United States', '66617');
insert into Address (AddressID, AddressLine1, AddressLine2, City, StateProvince, CountyRegion, PostalCode) values (10, '2 Victoria Pass', 'PO Box 51796', 'Velika', null, 'Croatia', '34330');
insert into Address (AddressID, AddressLine1, AddressLine2, City, StateProvince, CountyRegion, PostalCode) values (11, '93261 Dovetail Junction', 'Suite 18', 'Grängesberg', 'Dalarna', 'Sweden', '772 30');
insert into Address (AddressID, AddressLine1, AddressLine2, City, StateProvince, CountyRegion, PostalCode) values (12, '4 Thompson Center', '8th Floor', 'Jietou', null, 'China', null);
insert into Address (AddressID, AddressLine1, AddressLine2, City, StateProvince, CountyRegion, PostalCode) values (13, '943 Messerschmidt Point', 'PO Box 68805', 'Tomar', 'Santarém', 'Portugal', '2300-320');
insert into Address (AddressID, AddressLine1, AddressLine2, City, StateProvince, CountyRegion, PostalCode) values (14, '91165 6th Lane', 'PO Box 34831', 'Leijiadian', null, 'China', null);
insert into Address (AddressID, AddressLine1, AddressLine2, City, StateProvince, CountyRegion, PostalCode) values (15, '32 Westerfield Circle', 'Apt 1547', 'Thị Trấn Nga Sơn', null, 'Vietnam', null);
insert into Address (AddressID, AddressLine1, AddressLine2, City, StateProvince, CountyRegion, PostalCode) values (16, '3208 Eagle Crest Park', 'Room 628', 'Žirovnice', null, 'Czech Republic', '394 68');
insert into Address (AddressID, AddressLine1, AddressLine2, City, StateProvince, CountyRegion, PostalCode) values (17, '5470 Victoria Crossing', '16th Floor', 'Yuyapichis', null, 'Peru', null);
insert into Address (AddressID, AddressLine1, AddressLine2, City, StateProvince, CountyRegion, PostalCode) values (18, '31 Beilfuss Junction', 'PO Box 44654', 'Dayeuhluhur', null, 'Indonesia', null);
insert into Address (AddressID, AddressLine1, AddressLine2, City, StateProvince, CountyRegion, PostalCode) values (19, '44255 Amoth Way', 'Apt 1417', 'Nioro', null, 'Mali', null);
insert into Address (AddressID, AddressLine1, AddressLine2, City, StateProvince, CountyRegion, PostalCode) values (20, '2 Sunnyside Lane', 'PO Box 88966', 'Yuekou', null, 'China', null);

insert into CUSTOMERADDRESS (customerid, addressid, addresstype) values (1, 1, 'Home');
insert into CUSTOMERADDRESS (customerid, addressid, addresstype) values (2, 2, 'Home');
insert into CUSTOMERADDRESS (customerid, addressid, addresstype) values (3, 3, 'Home');
insert into CUSTOMERADDRESS (customerid, addressid, addresstype) values (4, 4, 'Home');
insert into CUSTOMERADDRESS (customerid, addressid, addresstype) values (5, 5, 'Home');
insert into CUSTOMERADDRESS (customerid, addressid, addresstype) values (6, 6, 'Home');
insert into CUSTOMERADDRESS (customerid, addressid, addresstype) values (7, 7, 'Home');
insert into CUSTOMERADDRESS (customerid, addressid, addresstype) values (8, 8, 'Home');
insert into CUSTOMERADDRESS (customerid, addressid, addresstype) values (9, 9, 'Home');
insert into CUSTOMERADDRESS (customerid, addressid, addresstype) values (10, 10, 'Home');
insert into CUSTOMERADDRESS (customerid, addressid, addresstype) values (11, 11, 'Home');
insert into CUSTOMERADDRESS (customerid, addressid, addresstype) values (12, 12, 'Home');
insert into CUSTOMERADDRESS (customerid, addressid, addresstype) values (13, 13, 'Home');
insert into CUSTOMERADDRESS (customerid, addressid, addresstype) values (14, 14, 'Home');
insert into CUSTOMERADDRESS (customerid, addressid, addresstype) values (15, 15, 'Home');
insert into CUSTOMERADDRESS (customerid, addressid, addresstype) values (16, 16, 'Home');
insert into CUSTOMERADDRESS (customerid, addressid, addresstype) values (17, 17, 'Home');
insert into CUSTOMERADDRESS (customerid, addressid, addresstype) values (18, 18, 'Home');
insert into CUSTOMERADDRESS (customerid, addressid, addresstype) values (19, 19, 'Home');
insert into CUSTOMERADDRESS (customerid, addressid, addresstype) values (20, 20, 'Home');

INSERT INTO SALESORDERHEADER (SalesOrderID, REVISIONNUMBER, ORDERDATE, CUSTOMERID, BILLTOADDRESSID, SHIPTOADDRESSID, SHIPMETHOD, SUBTOTAL, TAXAMT, FREIGHT) VALUES (1, 8, TO_DATE('2011-05-31 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), 1, 1, 1, 'CARGO TRANSPORT 5', 20565.6200, 1645.2500, 616.0984);
INSERT INTO SALESORDERHEADER (SalesOrderID, REVISIONNUMBER, ORDERDATE, CUSTOMERID, BILLTOADDRESSID, SHIPTOADDRESSID, SHIPMETHOD, SUBTOTAL, TAXAMT, FREIGHT) VALUES (2, 8, TO_DATE('2011-05-31 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), 2, 2, 2, 'CARGO TRANSPORT 5', 20565.6200, 1645.2500, 616.0984);
INSERT INTO SALESORDERHEADER (SalesOrderID, REVISIONNUMBER, ORDERDATE, CUSTOMERID, BILLTOADDRESSID, SHIPTOADDRESSID, SHIPMETHOD, SUBTOTAL, TAXAMT, FREIGHT) VALUES (3, 8, TO_DATE('2011-05-31 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), 3, 3, 3, 'CARGO TRANSPORT 5', 20565.6200, 1645.2500, 616.0984);
INSERT INTO SALESORDERHEADER (SalesOrderID, REVISIONNUMBER, ORDERDATE, CUSTOMERID, BILLTOADDRESSID, SHIPTOADDRESSID, SHIPMETHOD, SUBTOTAL, TAXAMT, FREIGHT) VALUES (4, 8, TO_DATE('2011-05-31 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), 4, 4, 4, 'CARGO TRANSPORT 5', 20565.6200, 1645.2500, 616.0984);
INSERT INTO SALESORDERHEADER (SalesOrderID, REVISIONNUMBER, ORDERDATE, CUSTOMERID, BILLTOADDRESSID, SHIPTOADDRESSID, SHIPMETHOD, SUBTOTAL, TAXAMT, FREIGHT) VALUES (5, 8, TO_DATE('2011-05-31 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), 5, 5, 5, 'CARGO TRANSPORT 5', 20565.6200, 1645.2500, 616.0984);
INSERT INTO SALESORDERHEADER (SalesOrderID, REVISIONNUMBER, ORDERDATE, CUSTOMERID, BILLTOADDRESSID, SHIPTOADDRESSID, SHIPMETHOD, SUBTOTAL, TAXAMT, FREIGHT) VALUES (6, 8, TO_DATE('2011-05-31 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), 6, 6, 6, 'CARGO TRANSPORT 5', 20565.6200, 1645.2500, 616.0984);
INSERT INTO SALESORDERHEADER (SalesOrderID, REVISIONNUMBER, ORDERDATE, CUSTOMERID, BILLTOADDRESSID, SHIPTOADDRESSID, SHIPMETHOD, SUBTOTAL, TAXAMT, FREIGHT) VALUES (7, 8, TO_DATE('2011-05-31 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), 7, 7, 7, 'CARGO TRANSPORT 5', 20565.6200, 1645.2500, 616.0984);
INSERT INTO SALESORDERHEADER (SalesOrderID, REVISIONNUMBER, ORDERDATE, CUSTOMERID, BILLTOADDRESSID, SHIPTOADDRESSID, SHIPMETHOD, SUBTOTAL, TAXAMT, FREIGHT)  VALUES (8, 8, TO_DATE('2011-05-31 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), 8, 8, 8, 'CARGO TRANSPORT 5', 20565.6200, 1645.2500, 616.0984);
INSERT INTO SALESORDERHEADER (SalesOrderID, REVISIONNUMBER, ORDERDATE, CUSTOMERID, BILLTOADDRESSID, SHIPTOADDRESSID, SHIPMETHOD, SUBTOTAL, TAXAMT, FREIGHT) VALUES (9, 8, TO_DATE('2011-05-31 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), 9, 9, 9, 'CARGO TRANSPORT 5', 20565.6200, 1645.2500, 616.0984);
INSERT INTO SALESORDERHEADER (SalesOrderID, REVISIONNUMBER, ORDERDATE, CUSTOMERID, BILLTOADDRESSID, SHIPTOADDRESSID, SHIPMETHOD, SUBTOTAL, TAXAMT, FREIGHT) VALUES (10, 8, TO_DATE('2011-05-31 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), 10, 10, 10, 'CARGO TRANSPORT 5', 20565.6200, 1645.2500, 616.0984);

insert into SALESORDERDETAIL (SALESORDERID, SALESORDERDETAILID, ORDERQTY, PRODUCTID, UNITPRICE, UNITPRICEDISCOUNT) VALUES (1, 1, 1, 1, 20565.6200, 0);
insert into SALESORDERDETAIL (SALESORDERID, SALESORDERDETAILID, ORDERQTY, PRODUCTID, UNITPRICE, UNITPRICEDISCOUNT) VALUES (2, 2, 8, 2, 2065.6700, 5);
insert into SALESORDERDETAIL (SALESORDERID, SALESORDERDETAILID, ORDERQTY, PRODUCTID, UNITPRICE, UNITPRICEDISCOUNT) VALUES (3, 3, 4, 3, 29465.5600, 0);
insert into SALESORDERDETAIL (SALESORDERID, SALESORDERDETAILID, ORDERQTY, PRODUCTID, UNITPRICE, UNITPRICEDISCOUNT) VALUES (4, 4, 9, 4, 28665.1400, 0);
insert into SALESORDERDETAIL (SALESORDERID, SALESORDERDETAILID, ORDERQTY, PRODUCTID, UNITPRICE, UNITPRICEDISCOUNT) VALUES (5, 5, 2, 5, 2565.4700, 10);
insert into SALESORDERDETAIL (SALESORDERID, SALESORDERDETAILID, ORDERQTY, PRODUCTID, UNITPRICE, UNITPRICEDISCOUNT) VALUES (6, 6, 10, 6, 341565.4300, 0);
insert into SALESORDERDETAIL (SALESORDERID, SALESORDERDETAILID, ORDERQTY, PRODUCTID, UNITPRICE, UNITPRICEDISCOUNT) VALUES (7, 7, 3, 7, 31265.7200, 5);
insert into SALESORDERDETAIL (SALESORDERID, SALESORDERDETAILID, ORDERQTY, PRODUCTID, UNITPRICE, UNITPRICEDISCOUNT) VALUES (8, 8, 11, 8, 2565.4700, 0);
insert into SALESORDERDETAIL (SALESORDERID, SALESORDERDETAILID, ORDERQTY, PRODUCTID, UNITPRICE, UNITPRICEDISCOUNT) VALUES (9, 9, 5, 9, 25965.4700, 0);
insert into SALESORDERDETAIL (SALESORDERID, SALESORDERDETAILID, ORDERQTY, PRODUCTID, UNITPRICE, UNITPRICEDISCOUNT) VALUES (10, 10, 12, 10, 2565.4000, 0);
insert into SALESORDERDETAIL (SALESORDERID, SALESORDERDETAILID, ORDERQTY, PRODUCTID, UNITPRICE, UNITPRICEDISCOUNT) VALUES (11, 11, 6, 11, 1565.7700, 0);
insert into SALESORDERDETAIL (SALESORDERID, SALESORDERDETAILID, ORDERQTY, PRODUCTID, UNITPRICE, UNITPRICEDISCOUNT) VALUES (12, 12, 13, 12, 565.4700, 7);
insert into SALESORDERDETAIL (SALESORDERID, SALESORDERDETAILID, ORDERQTY, PRODUCTID, UNITPRICE, UNITPRICEDISCOUNT) VALUES (13, 13, 7, 13, 355.2700, 0);
insert into SALESORDERDETAIL (SALESORDERID, SALESORDERDETAILID, ORDERQTY, PRODUCTID, UNITPRICE, UNITPRICEDISCOUNT) VALUES (14, 14, 14, 14, 6575.3200, 0);
insert into SALESORDERDETAIL (SALESORDERID, SALESORDERDETAILID, ORDERQTY, PRODUCTID, UNITPRICE, UNITPRICEDISCOUNT) VALUES (15, 15, 15, 15, 6575.3200, 0);
insert into SALESORDERDETAIL (SALESORDERID, SALESORDERDETAILID, ORDERQTY, PRODUCTID, UNITPRICE, UNITPRICEDISCOUNT) VALUES (16, 16, 16, 16, 6575.3200, 0);
insert into SALESORDERDETAIL (SALESORDERID, SALESORDERDETAILID, ORDERQTY, PRODUCTID, UNITPRICE, UNITPRICEDISCOUNT) VALUES (17, 17, 17, 17, 6575.3200, 0);
insert into SALESORDERDETAIL (SALESORDERID, SALESORDERDETAILID, ORDERQTY, PRODUCTID, UNITPRICE, UNITPRICEDISCOUNT) VALUES (18, 18, 18, 18, 6575.3200, 0);
insert into SALESORDERDETAIL (SALESORDERID, SALESORDERDETAILID, ORDERQTY, PRODUCTID, UNITPRICE, UNITPRICEDISCOUNT) VALUES (19, 19, 19, 19, 6575.3200, 0);
insert into SALESORDERDETAIL (SALESORDERID, SALESORDERDETAILID, ORDERQTY, PRODUCTID, UNITPRICE, UNITPRICEDISCOUNT) VALUES (20, 20, 20, 20, 6575.3200, 0);

insert into PRODUCTMODEL (PRODUCTMODELID, NAME) values (1, 'Model 1');
insert into PRODUCTMODEL (PRODUCTMODELID, NAME) values (2, 'Model 2');
insert into PRODUCTMODEL (PRODUCTMODELID, NAME) values (3, 'Model 3');
insert into PRODUCTMODEL (PRODUCTMODELID, NAME) values (4, 'Model 4');
insert into PRODUCTMODEL (PRODUCTMODELID, NAME) values (5, 'Model 5');
insert into PRODUCTMODEL (PRODUCTMODELID, NAME) values (6, 'Model 6');
insert into PRODUCTMODEL (PRODUCTMODELID, NAME) values (7, 'Model 7');
insert into PRODUCTMODEL (PRODUCTMODELID, NAME) values (8, 'Model 8');
insert into PRODUCTMODEL (PRODUCTMODELID, NAME) values (9, 'Model 9');
insert into PRODUCTMODEL (PRODUCTMODELID, NAME) values (10, 'Model 10');
insert into PRODUCTMODEL (PRODUCTMODELID, NAME) values (11, 'Model 11');
insert into PRODUCTMODEL (PRODUCTMODELID, NAME) values (12, 'Model 12');
insert into PRODUCTMODEL (PRODUCTMODELID, NAME) values (13, 'Model 13');
insert into PRODUCTMODEL (PRODUCTMODELID, NAME) values (14, 'Model 14');
insert into PRODUCTMODEL (PRODUCTMODELID, NAME) values (15, 'Model 15');
insert into PRODUCTMODEL (PRODUCTMODELID, NAME) values (16, 'Model 16');
insert into PRODUCTMODEL (PRODUCTMODELID, NAME) values (17, 'Model 17');
insert into PRODUCTMODEL (PRODUCTMODELID, NAME) values (18, 'Model 18');
insert into PRODUCTMODEL (PRODUCTMODELID, NAME) values (19, 'Model 19');
insert into PRODUCTMODEL (PRODUCTMODELID, NAME) values (20, 'Model 20');

insert into PRODUCTCATEGORY (PRODUCTCATEGORYID, PARENTPRODUCTCATEGORYID, NAME) values (1, 1, 'Category 1');
insert into PRODUCTCATEGORY (PRODUCTCATEGORYID, PARENTPRODUCTCATEGORYID, NAME) values (2, 2, 'Category 2');
insert into PRODUCTCATEGORY (PRODUCTCATEGORYID, PARENTPRODUCTCATEGORYID, NAME) values (3, 3, 'Category 3');
insert into PRODUCTCATEGORY (PRODUCTCATEGORYID, PARENTPRODUCTCATEGORYID, NAME) values (4, 4, 'Category 4');
insert into PRODUCTCATEGORY (PRODUCTCATEGORYID, PARENTPRODUCTCATEGORYID, NAME) values (5, 5, 'Category 5');
insert into PRODUCTCATEGORY (PRODUCTCATEGORYID, PARENTPRODUCTCATEGORYID, NAME) values (6, 6, 'Category 6');
insert into PRODUCTCATEGORY (PRODUCTCATEGORYID, PARENTPRODUCTCATEGORYID, NAME) values (7, 7, 'Category 7');
insert into PRODUCTCATEGORY (PRODUCTCATEGORYID, PARENTPRODUCTCATEGORYID, NAME) values (8, 8, 'Category 8');
insert into PRODUCTCATEGORY (PRODUCTCATEGORYID, PARENTPRODUCTCATEGORYID, NAME) values (9, 9, 'Category 9');
insert into PRODUCTCATEGORY (PRODUCTCATEGORYID, PARENTPRODUCTCATEGORYID, NAME) values (10, 10, 'Category 10');
insert into PRODUCTCATEGORY (PRODUCTCATEGORYID, PARENTPRODUCTCATEGORYID, NAME) values (11, 11, 'Category 11');
insert into PRODUCTCATEGORY (PRODUCTCATEGORYID, PARENTPRODUCTCATEGORYID, NAME) values (12, 12, 'Category 12');
insert into PRODUCTCATEGORY (PRODUCTCATEGORYID, PARENTPRODUCTCATEGORYID, NAME) values (13, 13, 'Category 13');
insert into PRODUCTCATEGORY (PRODUCTCATEGORYID, PARENTPRODUCTCATEGORYID, NAME) values (14, 14, 'Category 14');
insert into PRODUCTCATEGORY (PRODUCTCATEGORYID, PARENTPRODUCTCATEGORYID, NAME) values (15, 15, 'Category 15');
insert into PRODUCTCATEGORY (PRODUCTCATEGORYID, PARENTPRODUCTCATEGORYID, NAME) values (16, 16, 'Category 16');
insert into PRODUCTCATEGORY (PRODUCTCATEGORYID, PARENTPRODUCTCATEGORYID, NAME) values (17, 17, 'Category 17');
insert into PRODUCTCATEGORY (PRODUCTCATEGORYID, PARENTPRODUCTCATEGORYID, NAME) values (18, 18, 'Category 18');
insert into PRODUCTCATEGORY (PRODUCTCATEGORYID, PARENTPRODUCTCATEGORYID, NAME) values (19, 19, 'Category 19');
insert into PRODUCTCATEGORY (PRODUCTCATEGORYID, PARENTPRODUCTCATEGORYID, NAME) values (20, 20, 'Category 20');

insert into PRODUCT (PRODUCTID, NAME, COLOR, LISTPRICE, SIZEP, WEIGHT, PRODUCTMODELID, PRODUCTCATEGORYID) values (1, 'Product 1', 'Red', 100.00, 10, 1, 1, 1);
insert into PRODUCT (PRODUCTID, NAME, COLOR, LISTPRICE, SIZEP, WEIGHT, PRODUCTMODELID, PRODUCTCATEGORYID) values (2, 'Product 2', 'Blue', 200.00, 20, 2, 2, 2);
insert into PRODUCT (PRODUCTID, NAME, COLOR, LISTPRICE, SIZEP, WEIGHT, PRODUCTMODELID, PRODUCTCATEGORYID) values (3, 'Product 3', 'Green', 300.00, 30, 3, 3, 3);
insert into PRODUCT (PRODUCTID, NAME, COLOR, LISTPRICE, SIZEP, WEIGHT, PRODUCTMODELID, PRODUCTCATEGORYID) values (4, 'Product 4', 'Yellow', 400.00, 40, 4, 4, 4);
insert into PRODUCT (PRODUCTID, NAME, COLOR, LISTPRICE, SIZEP, WEIGHT, PRODUCTMODELID, PRODUCTCATEGORYID) values (5, 'Product 5', 'Orange', 500.00, 50, 5, 5, 5);
insert into PRODUCT (PRODUCTID, NAME, COLOR, LISTPRICE, SIZEP, WEIGHT, PRODUCTMODELID, PRODUCTCATEGORYID) values (6, 'Product 6', 'Purple', 600.00, 60, 6, 6, 6);
insert into PRODUCT (PRODUCTID, NAME, COLOR, LISTPRICE, SIZEP, WEIGHT, PRODUCTMODELID, PRODUCTCATEGORYID) values (7, 'Product 7', 'Black', 700.00, 70, 7, 7, 7);
insert into PRODUCT (PRODUCTID, NAME, COLOR, LISTPRICE, SIZEP, WEIGHT, PRODUCTMODELID, PRODUCTCATEGORYID) values (8, 'Product 8', 'White', 800.00, 80, 8, 8, 8);
insert into PRODUCT (PRODUCTID, NAME, COLOR, LISTPRICE, SIZEP, WEIGHT, PRODUCTMODELID, PRODUCTCATEGORYID) values (9, 'Product 9', 'Brown', 900.00, 90, 9, 9, 9);
insert into PRODUCT (PRODUCTID, NAME, COLOR, LISTPRICE, SIZEP, WEIGHT, PRODUCTMODELID, PRODUCTCATEGORYID) values (10, 'Product 10', 'Pink', 1000.00, 100, 10, 10, 10);
insert into PRODUCT (PRODUCTID, NAME, COLOR, LISTPRICE, SIZEP, WEIGHT, PRODUCTMODELID, PRODUCTCATEGORYID) values (11, 'Product 11', 'Gray', 1100.00, 110, 11, 11, 11);
insert into PRODUCT (PRODUCTID, NAME, COLOR, LISTPRICE, SIZEP, WEIGHT, PRODUCTMODELID, PRODUCTCATEGORYID) values (12, 'Product 12', 'Cyan', 1200.00, 120, 12, 12, 12);
insert into PRODUCT (PRODUCTID, NAME, COLOR, LISTPRICE, SIZEP, WEIGHT, PRODUCTMODELID, PRODUCTCATEGORYID) values (13, 'Product 13', 'Magenta', 1300.00, 130, 13, 13, 13);
insert into PRODUCT (PRODUCTID, NAME, COLOR, LISTPRICE, SIZEP, WEIGHT, PRODUCTMODELID, PRODUCTCATEGORYID) values (14, 'Product 14', 'Lime', 1400.00, 140, 14, 14, 14);
insert into PRODUCT (PRODUCTID, NAME, COLOR, LISTPRICE, SIZEP, WEIGHT, PRODUCTMODELID, PRODUCTCATEGORYID) values (15, 'Product 15', 'Teal', 1500.00, 150, 15, 15, 15);
insert into PRODUCT (PRODUCTID, NAME, COLOR, LISTPRICE, SIZEP, WEIGHT, PRODUCTMODELID, PRODUCTCATEGORYID) values (16, 'Product 16', 'Maroon', 1600.00, 160, 16, 16, 16);
insert into PRODUCT (PRODUCTID, NAME, COLOR, LISTPRICE, SIZEP, WEIGHT, PRODUCTMODELID, PRODUCTCATEGORYID) values (17, 'Product 17', 'Olive', 1700.00, 170, 17, 17, 17);
insert into PRODUCT (PRODUCTID, NAME, COLOR, LISTPRICE, SIZEP, WEIGHT, PRODUCTMODELID, PRODUCTCATEGORYID) values (18, 'Product 18', 'Navy', 1800.00, 180, 18, 18, 18);
insert into PRODUCT (PRODUCTID, NAME, COLOR, LISTPRICE, SIZEP, WEIGHT, PRODUCTMODELID, PRODUCTCATEGORYID) values (19, 'Product 19', 'Aquamarine', 1900.00, 190, 19, 19, 19);
insert into PRODUCT (PRODUCTID, NAME, COLOR, LISTPRICE, SIZEP, WEIGHT, PRODUCTMODELID, PRODUCTCATEGORYID) values (20, 'Product 20', 'Turquoise', 2000.00, 200, 20, 20, 20);

insert into PRODUCTDESCRIPTION (PRODUCTDESCRIPTIONID, DESCRIPTION) VALUES (1, 'Description 1');
insert into PRODUCTDESCRIPTION (PRODUCTDESCRIPTIONID, DESCRIPTION) VALUES (2, 'Description 2');
insert into PRODUCTDESCRIPTION (PRODUCTDESCRIPTIONID, DESCRIPTION) VALUES (3, 'Description 3');
insert into PRODUCTDESCRIPTION (PRODUCTDESCRIPTIONID, DESCRIPTION) VALUES (4, 'Description 4');
insert into PRODUCTDESCRIPTION (PRODUCTDESCRIPTIONID, DESCRIPTION) VALUES (5, 'Description 5');
insert into PRODUCTDESCRIPTION (PRODUCTDESCRIPTIONID, DESCRIPTION) VALUES (6, 'Description 6');
insert into PRODUCTDESCRIPTION (PRODUCTDESCRIPTIONID, DESCRIPTION) VALUES (7, 'Description 7');
insert into PRODUCTDESCRIPTION (PRODUCTDESCRIPTIONID, DESCRIPTION) VALUES (8, 'Description 8');
insert into PRODUCTDESCRIPTION (PRODUCTDESCRIPTIONID, DESCRIPTION) VALUES (9, 'Description 9');
insert into PRODUCTDESCRIPTION (PRODUCTDESCRIPTIONID, DESCRIPTION) VALUES (10, 'Description 10');
insert into PRODUCTDESCRIPTION (PRODUCTDESCRIPTIONID, DESCRIPTION) VALUES (11, 'Description 11');
insert into PRODUCTDESCRIPTION (PRODUCTDESCRIPTIONID, DESCRIPTION) VALUES (12, 'Description 12');
insert into PRODUCTDESCRIPTION (PRODUCTDESCRIPTIONID, DESCRIPTION) VALUES (13, 'Description 13');
insert into PRODUCTDESCRIPTION (PRODUCTDESCRIPTIONID, DESCRIPTION) VALUES (14, 'Description 14');
insert into PRODUCTDESCRIPTION (PRODUCTDESCRIPTIONID, DESCRIPTION) VALUES (15, 'Description 15');
insert into PRODUCTDESCRIPTION (PRODUCTDESCRIPTIONID, DESCRIPTION) VALUES (16, 'Description 16');
insert into PRODUCTDESCRIPTION (PRODUCTDESCRIPTIONID, DESCRIPTION) VALUES (17, 'Description 17');
insert into PRODUCTDESCRIPTION (PRODUCTDESCRIPTIONID, DESCRIPTION) VALUES (18, 'Description 18');
insert into PRODUCTDESCRIPTION (PRODUCTDESCRIPTIONID, DESCRIPTION) VALUES (19, 'Description 19');
insert into PRODUCTDESCRIPTION (PRODUCTDESCRIPTIONID, DESCRIPTION) VALUES (20, 'Description 20');

insert into PRODUCTMODELPRODUCTDESCRIPTION (PRODUCTMODELID, PRODUCTDESCRIPTIONID, CULTURE) VALUES (1, 1, 'en');
insert into PRODUCTMODELPRODUCTDESCRIPTION (PRODUCTMODELID, PRODUCTDESCRIPTIONID, CULTURE) VALUES (2, 2, 'en');
insert into PRODUCTMODELPRODUCTDESCRIPTION (PRODUCTMODELID, PRODUCTDESCRIPTIONID, CULTURE) VALUES (3, 3, 'en');
insert into PRODUCTMODELPRODUCTDESCRIPTION (PRODUCTMODELID, PRODUCTDESCRIPTIONID, CULTURE) VALUES (4, 4, 'en');
insert into PRODUCTMODELPRODUCTDESCRIPTION (PRODUCTMODELID, PRODUCTDESCRIPTIONID, CULTURE) VALUES (5, 5, 'en');
insert into PRODUCTMODELPRODUCTDESCRIPTION (PRODUCTMODELID, PRODUCTDESCRIPTIONID, CULTURE) VALUES (6, 6, 'en');
insert into PRODUCTMODELPRODUCTDESCRIPTION (PRODUCTMODELID, PRODUCTDESCRIPTIONID, CULTURE) VALUES (7, 7, 'en');
insert into PRODUCTMODELPRODUCTDESCRIPTION (PRODUCTMODELID, PRODUCTDESCRIPTIONID, CULTURE) VALUES (8, 8, 'en');
insert into PRODUCTMODELPRODUCTDESCRIPTION (PRODUCTMODELID, PRODUCTDESCRIPTIONID, CULTURE) VALUES (9, 9, 'en');
insert into PRODUCTMODELPRODUCTDESCRIPTION (PRODUCTMODELID, PRODUCTDESCRIPTIONID, CULTURE) VALUES (10, 10, 'en');
insert into PRODUCTMODELPRODUCTDESCRIPTION (PRODUCTMODELID, PRODUCTDESCRIPTIONID, CULTURE) VALUES (11, 11, 'en');
insert into PRODUCTMODELPRODUCTDESCRIPTION (PRODUCTMODELID, PRODUCTDESCRIPTIONID, CULTURE) VALUES (12, 12, 'en');
insert into PRODUCTMODELPRODUCTDESCRIPTION (PRODUCTMODELID, PRODUCTDESCRIPTIONID, CULTURE) VALUES (13, 13, 'en');
insert into PRODUCTMODELPRODUCTDESCRIPTION (PRODUCTMODELID, PRODUCTDESCRIPTIONID, CULTURE) VALUES (14, 14, 'en');
insert into PRODUCTMODELPRODUCTDESCRIPTION (PRODUCTMODELID, PRODUCTDESCRIPTIONID, CULTURE) VALUES (15, 15, 'en');
insert into PRODUCTMODELPRODUCTDESCRIPTION (PRODUCTMODELID, PRODUCTDESCRIPTIONID, CULTURE) VALUES (16, 16, 'en');
insert into PRODUCTMODELPRODUCTDESCRIPTION (PRODUCTMODELID, PRODUCTDESCRIPTIONID, CULTURE) VALUES (17, 17, 'en');
insert into PRODUCTMODELPRODUCTDESCRIPTION (PRODUCTMODELID, PRODUCTDESCRIPTIONID, CULTURE) VALUES (18, 18, 'en');
insert into PRODUCTMODELPRODUCTDESCRIPTION (PRODUCTMODELID, PRODUCTDESCRIPTIONID, CULTURE) VALUES (19, 19, 'en');
insert into PRODUCTMODELPRODUCTDESCRIPTION (PRODUCTMODELID, PRODUCTDESCRIPTIONID, CULTURE) VALUES (20, 20, 'en');

-- PoblarNoOk

INSERT INTO SALESORDERDETAIL (SALESORDERID, SALESORDERDETAILID, ORDERQTY, PRODUCTID, UNITPRICE, UNITPRICEDISCOUNT) 
VALUES (1, 1, 2, 1, 15000, 0);

INSERT INTO SALESORDERDETAIL (SALESORDERID, SALESORDERDETAILID, ORDERQTY, PRODUCTID, UNITPRICE, UNITPRICEDISCOUNT) 
VALUES (2, 2, NULL, 2, 15000, 0);


-- Consultas

SELECT CompanyName
  FROM Customer
 WHERE FirstName='Martita'
   AND MiddleName='Danella'
   AND LastName='Fernyhough'

SELECT CompanyName,AddressType,AddressLine1
  FROM Customer JOIN CustomerAddress
    ON (Customer.CustomerID=CustomerAddress.CustomerID)
                  JOIN Address
    ON (CustomerAddress.AddressID=Address.AddressID)
 WHERE CompanyName='Mydeo'
 
SELECT OrderQty,Name,ListPrice
FROM SalesOrderHeader JOIN SalesOrderDetail
          ON SalesOrderDetail.SalesOrderID = SalesOrderHeader.SalesOrderID
                        JOIN Product
          ON SalesOrderDetail.ProductID=Product.ProductID
WHERE CustomerID= 5

SELECT Name,ListPrice
FROM Product
ORDER BY ListPrice DESC

SELECT * 
FROM Address

--XPoblar

TRUNCATE TABLE CUSTOMER;
TRUNCATE TABLE CUSTOMERADDRESS;
TRUNCATE TABLE ADDRESS;
TRUNCATE TABLE SALESORDERHEADER;
TRUNCATE TABLE SALESORDERDETAIL;
TRUNCATE TABLE PRODUCT;
TRUNCATE TABLE PRODUCTMODEL;
TRUNCATE TABLE PRODUCTCATEGORY;
TRUNCATE TABLE PRODUCTMODELPRODUCTDESCRIPTION;
TRUNCATE TABLE PRODUCTDESCRIPTION;

--XTablas

DROP TABLE CUSTOMER CASCADE CONSTRAINTS;
DROP TABLE CUSTOMERADDRESS CASCADE CONSTRAINTS;
DROP TABLE ADDRESS CASCADE CONSTRAINTS;
DROP TABLE SALESORDERHEADER CASCADE CONSTRAINTS;
DROP TABLE SALESORDERDETAIL CASCADE CONSTRAINTS;
DROP TABLE PRODUCT CASCADE CONSTRAINTS;
DROP TABLE PRODUCTMODEL CASCADE CONSTRAINTS;
DROP TABLE PRODUCTCATEGORY CASCADE CONSTRAINTS;
DROP TABLE PRODUCTMODELPRODUCTDESCRIPTION CASCADE CONSTRAINTS;
DROP TABLE PRODUCTDESCRIPTION CASCADE CONSTRAINTS;

-- Atributos

ALTER TABLE ProductModel
ADD CONSTRAINT CK_PMODEL_ID CHECK (T10Natural > 0);

ALTER TABLE ProductDescription
ADD CONSTRAINT CK_PDESCRIPTION_ID CHECK (T10Natural > 0);

ALTER TABLE ProductModel
ADD CONSTRAINT CK_PMODEL_NAME CHECK (REGEXP_LIKE(TPMName, '^[a-zA-Z]+[ -][a-zA-Z]+$'));

ALTER TABLE ProductModelProductDescription
ADD CONSTRAINT CK_PMODELPRODUCT_CULTURE CHECK (TCulture IN ('en', 'ar', 'fr', 'th', 'he', 'zh-cht', 'co'));


-- Tuplas



-- AtributosOK

-- Atributos válidos: CustomerID es un número positivo y EmailAddress cumple con el formato especificado
INSERT INTO Customer (CustomerID, FirstName, MiddleName, LastName, CompanyName, EmailAddress)
VALUES (1, 'John', 'A', 'Doe', 'Company Inc.', 'john.doe@example.com');

-- Atributos válidos: AddressID es un número positivo y PostalCode cumple con el formato especificado
INSERT INTO Address (AddressID, AddressLine1, AddressLine2, City, StateProvince, CountyRegion, PostalCode)
VALUES (1, '123 Main St', 'Apt 4', 'Anytown', 'Anystate', 'Anyregion', '12345');

-- Atributos válidos: CustomerID y AddressID existen en las tablas Customer y Address respectivamente
INSERT INTO CustomerAddress (CustomerID, AddressID, AddressType)
VALUES (1, 1, 'Home');

-- AtributosNoOK

-- Atributos no válidos: EmailAddress no cumple con el formato especificado :3
INSERT INTO Customer (CustomerID, FirstName, MiddleName, LastName, CompanyName, EmailAddress)
VALUES (2, 'Jane', 'B', 'Smith', 'Company LLC', 'jane.smith@com');

-- Atributos no válidos: PostalCode no cumple con el formato especificado
INSERT INTO Address (AddressID, AddressLine1, AddressLine2, City, StateProvince, CountyRegion, PostalCode)
VALUES (2, '456 Elm St', 'Suite 5', 'Othertown', 'Otherstate', 'Otherregion', 'ABCDE');

-- Atributos no válidos: CustomerID no existe en la tabla Customer :p
INSERT INTO CustomerAddress (CustomerID, AddressID, AddressType)
VALUES (999, 1, 'Work');

-- TuplasOK



-- TuplasNoOK



-- Acciones

ALTER TABLE ProductModel
ADD CONSTRAINT PK_PMOEL
PRIMARY KEY (ProductModelID)

ALTER TABLE ProductModel
ADD CONSTRAINT UK_PMOEL_NAME
UNIQUE (Name)

ALTER TABLE PRODUCTMODELPRODUCTDESCRIPTION
ADD CONSTRAINT FFK_PMODELPRODUCT_PMODEL FOREIGN KEY (PRODUCTMODELID) REFERENCES ProductModel(PRODUCTMODELID);

ALTER TABLE PRODUCTMODELPRODUCTDESCRIPTION
ADD CONSTRAINT FK_PMODELPRODUCT_PDESCRIPTION FOREIGN KEY (PRODUCTDESCRIPTIONID) REFERENCES ProductDescription(PRODUCTDESCRIPTIONID);

-- AccionesOK



-- Disparadores 

CREATE TRIGGER
BEFORE
ON
[FOR EACH ROW {WHEN()]]
DECLARE
BEGIN

END  ;


CREATE TRIGGER TR_PMODEL_BI
BEFORE INSERT
ON ProductModel
DECLARE
nuevo.numero := 1
BEGIN
    SELECT MAX(numero) INTO nuevo.numero FROM  ProductModel
    IF nuevo.numero is NULL
    :new.numero = 1,
    ELSE
    :New.numero = nuevo.numero + 1
    END IF
END;

CREATE OR REPLACE TRIGGER TR_PMODEL_BU
BEFORE INSERT ON ProductModel
FOR EACH ROW
BEGIN
    IF :NEW.ProductModelID IS NOT NULL THEN
        RAISE_APPLICATION_ERROR(-20001, 'No se pueden insertar valores');
    END IF;
END;

CREATE OR REPLACE TRIGGER TR_PMODELPRODUCT_BU
BEFORE INSERT ON ProductModel
FOR EACH ROW
BEGIN
    IF :NEW.Name IS NOT NULL THEN
        RAISE_APPLICATION_ERROR(-20001, 'No se pueden insertar valores');
    END IF;
END;


CREATE OR REPLACE TRIGGER TR_PDESCRIPTION_BU
BEFORE INSERT ON ProductModel
FOR EACH ROW
BEGIN
    IF :NEW.CatalogDescription IS NOT NULL THEN
        RAISE_APPLICATION_ERROR(-20001, 'No se pueden insertar valores');
    END IF;
END;





CREATE TRIGGER

-- XDisparadores



-- DisparadoresOK



-- DisparadoresNoOK


