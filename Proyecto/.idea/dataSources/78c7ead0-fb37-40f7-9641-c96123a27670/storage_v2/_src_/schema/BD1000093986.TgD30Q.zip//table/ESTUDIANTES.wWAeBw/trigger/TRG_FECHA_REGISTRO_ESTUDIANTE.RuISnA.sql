create trigger TRG_FECHA_REGISTRO_ESTUDIANTE
    before insert
    on ESTUDIANTES
    for each row
BEGIN
    :NEW.fechaRegistro := SYSDATE;
END;
/

