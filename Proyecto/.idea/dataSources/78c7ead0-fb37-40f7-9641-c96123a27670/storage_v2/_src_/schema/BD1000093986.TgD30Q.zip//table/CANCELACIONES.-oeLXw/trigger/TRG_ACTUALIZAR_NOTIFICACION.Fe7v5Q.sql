create trigger TRG_ACTUALIZAR_NOTIFICACION
    after insert
    on CANCELACIONES
    for each row
BEGIN
    UPDATE NOTIFICACIONES
    SET estado = 'enviado'
    WHERE idNotificacion = :NEW.idNotificacion;
END;
/

