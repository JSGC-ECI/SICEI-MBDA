create trigger TRG_VERIFICAR_CREDITOS_HORAS
    before insert or update
    on MATERIAS
    for each row
BEGIN
    IF :NEW.creditos <= 0 THEN
        RAISE_APPLICATION_ERROR(-20005, 'Los créditos de la materia deben ser un número positivo');
    END IF;

    IF :NEW.horasTeoricas < 0 THEN
        RAISE_APPLICATION_ERROR(-20006, 'Las horas teóricas no pueden ser negativas');
    END IF;

    IF :NEW.horasPracticas < 0 THEN
        RAISE_APPLICATION_ERROR(-20007, 'Las horas prácticas no pueden ser negativas');
    END IF;
END;
/

