create trigger TRG_VALIDAR_PREREQUISITOS
    before insert or update
    on PREREQUISITOSMATERIAS
    for each row
BEGIN
    IF :NEW.idMateria = :NEW.idMateriaRequisito THEN
        RAISE_APPLICATION_ERROR(-20008, 'Una materia no puede ser prerequisito de sí misma');
    END IF;
END;
/

