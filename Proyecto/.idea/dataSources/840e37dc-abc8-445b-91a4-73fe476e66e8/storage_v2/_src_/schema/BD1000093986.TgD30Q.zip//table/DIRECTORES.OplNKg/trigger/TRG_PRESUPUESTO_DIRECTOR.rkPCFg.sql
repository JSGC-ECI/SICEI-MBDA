create trigger TRG_PRESUPUESTO_DIRECTOR
    before insert
    on DIRECTORES
    for each row
BEGIN
    :NEW.presupuestoAsignados := 1000000.00;
END;
/

