create trigger TRG_FECHA_NOTIFICACION
    before insert
    on NOTIFICACIONES
    for each row
BEGIN
    :NEW.fecha := SYSDATE;
END;
/

