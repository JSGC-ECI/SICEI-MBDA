create trigger TRG_VALIDAR_FECHA_INGRESO
    before insert or update
    on ESTUDIANTES
    for each row
BEGIN
    IF :NEW.fechaIngreso < :NEW.fechaRegistro THEN
        RAISE_APPLICATION_ERROR(-20002, 'La fecha de ingreso no puede ser anterior a la fecha de registro');
    END IF;
END;
/

