create trigger TRG_VERIFICAR_CUPO_GRUPO
    before insert or update
    on GRUPOS
    for each row
BEGIN
    IF :NEW.cupoMaximo <= 0 THEN
        RAISE_APPLICATION_ERROR(-20004, 'El cupo máximo del grupo debe ser un número positivo');
    END IF;
END;
/

